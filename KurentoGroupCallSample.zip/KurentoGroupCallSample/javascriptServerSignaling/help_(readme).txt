
# iamir-kurento-group-call


### Required

Node Version: Node 8.x

### install
```
npm install bower -g

npm run get
```

### edit
```
./server/index.js 

const argv = minimst(process.argv.slice(2), {
    default: {
        as_uri: 'https://localhost:3000',
        ws_uri: 'ws://127.0.0.1:8888/kurento'   // your KMS uri
    }
});
```

### run
```
 node index.js 
```