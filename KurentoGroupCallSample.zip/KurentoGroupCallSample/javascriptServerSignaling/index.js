import "babel-register";
import "babel-polyfill";


import './handler/index.js';