package net.iamir.projects.kurentogroupcall.lib.rtc;

import static org.webrtc.SessionDescription.Type.ANSWER;
import static org.webrtc.SessionDescription.Type.OFFER;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.preference.PreferenceManager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;


import net.iamir.projects.kurentogroupcall.GroupCallActivity;
import net.iamir.projects.kurentogroupcall.LoginActivity;
import net.iamir.projects.kurentogroupcall.adabters.RecordAdapter;
import net.iamir.projects.kurentogroupcall.databinding.ActivityGroupCallBinding;
import net.iamir.projects.kurentogroupcall.lib.kurento.KurentoRoomAPI;
import net.iamir.projects.kurentogroupcall.models.Record;
import net.iamir.projects.kurentogroupcall.utils.Constants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.SessionDescription;
import org.webrtc.VideoTrack;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import io.socket.emitter.Emitter;

public class Client {

    public Activity context;
    public ActivityGroupCallBinding binding;

    private static final String TAG = "iClient";
    public static final int VIDEO_RESOLUTION_WIDTH = 24;//640;
    public static final int VIDEO_RESOLUTION_HEIGHT = 24;//480;
    public static final int FPS = 10;//20;

    MediaConstraints audioConstraints;
    AudioSource audioSource;
    AudioTrack localAudioTrack;

   // public EglBase rootEglBase;
    public HashMap<String, EglBase> rootsEglBase = new HashMap<String, EglBase>();
    //public PeerConnectionFactory factory;
    public HashMap<String, PeerConnectionFactory> factories = new HashMap<String, PeerConnectionFactory>();

    public HashMap<String, PeerConnection> peerConnections = new HashMap<String, PeerConnection>();

    public VideoTrack videoTrackFromCamera;

    public AudioManager audioManager;

    public KurentoRoomAPI kurentoRoomAPI;

    public String username, roomname;

    public String wsUri;

    public RecordAdapter recordAdapter;

    public Record localRecord = new Record();

    public HashMap<String, Boolean> useRecords = new HashMap<String, Boolean>();

    List<String> STUNList= Arrays.asList(
      "stun:stun1.l.google.com:19302"/*,
      "stun:stun2.l.google.com:19302",
      "stun:stun3.l.google.com:19302",
      "stun:stun4.l.google.com:19302",
      "stun:stun.ekiga.net",
      "stun:stun.ideasip.com",
      "stun:stun.rixtelecom.se",
      "stun:stun.schlund.de",
      "stun:stun.stunprotocol.org:3478",
      "stun:stun.voiparound.com",
      "stun:stun.voipbuster.com",
      "stun:stun.voipstunt.com",
      "stun:stun.voxgratia.org"//*/
    );

    public Client(Activity context, ActivityGroupCallBinding binding) {
        this.context = context;
        this.binding = binding;

        audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);

        //rootEglBase = EglBase.create();

        recordAdapter = new RecordAdapter(this, onRecordItemClick, onRecordItemBindEnd);

        binding.rvRecords.setLayoutManager(new GridLayoutManager(this.context, 2, LinearLayoutManager.VERTICAL, false));
        binding.rvRecords.setAdapter(recordAdapter);

        SharedPreferences mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context.getBaseContext());

        Constants.SERVER_ADDRESS_SET_BY_USER = mSharedPreferences.getString(Constants.SERVER_NAME, Constants.DEFAULT_SERVER);

        wsUri = mSharedPreferences.getString(Constants.SERVER_NAME, Constants.DEFAULT_SERVER);

        kurentoRoomAPI = new KurentoRoomAPI(wsUri);

        if (!kurentoRoomAPI.isWebSocketConnected()) {
            kurentoRoomAPI.connectWebSocket();
        }

        if (kurentoRoomAPI.isWebSocketConnected()) {
            username     = mSharedPreferences.getString(Constants.USER_NAME, "");
            roomname     = mSharedPreferences.getString(Constants.ROOM_NAME, "");

            kurentoRoomAPI.sendJoinRoom(username, roomname);
            kurentoRoomAPI.client.service.on("message", iMessage);
        }
    }

    private Emitter.Listener iMessage = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            context.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject data = (JSONObject) args[0];
                    try {
                        Log.d(TAG, "Receiving " + data.getString("id") + " : " + data);
                        switch (data.getString("id")) {
                            case "existingParticipants":
                                localRecord.setType("local");
                                localRecord.setConnId(username);
                                localRecord.setName(username);
                                localRecord.setRoom(roomname);
                                initializeAddRecord(username);
                                recordAdapter.addRecord(localRecord);
                                JSONArray items = data.getJSONArray("data");
                                for (int i=0; i<items.length(); i++)
                                {
                                    try{
                                        JSONObject item = items.getJSONObject(i);
                                        Record record = new Record();
                                        record.setType("remote");
                                        record.setName(item.getString("name"));
                                        record.setConnId(item.getString("name"));
                                        record.setRoom(data.getString("roomName"));
                                        initializeAddRecord(item.getString("name"));
                                        recordAdapter.addRecord(record);
                                    }catch (JSONException e){
                                        Log.e(TAG,"existingParticipants: " + e.toString());
                                    }
                                }
                                break;
                            case "newParticipantArrived":
                                Record record = new Record();
                                record.setName(data.getString("name"));
                                record.setConnId(data.getString("name"));
                                record.setRoom(data.getString("room"));
                                initializeAddRecord(data.getString("name"));
                                recordAdapter.addRecord(record);
                                break;
                            case "participantLeft":
                                if (data.getString("name").equals(username))
                                    discount(data.getString("name"));
                                else
                                    remove(data.getString("name"));
                                break;
                            case "receiveVideoAnswer":
                                peerConnections.get(data.getString("name")).setRemoteDescription(new SimpleSdpObserver(), new SessionDescription(ANSWER, data.getString("sdpAnswer")));
                                break;
                            case "iceCandidate":
                                JSONObject  candidate = (JSONObject ) data.get("candidate");
                                String sdpMid = candidate.get("sdpMid").toString();
                                int sdpMLineIndex = Integer.valueOf(candidate.get("sdpMLineIndex").toString());
                                String sdp = candidate.get("candidate").toString();
                                IceCandidate ic = new IceCandidate(sdpMid, sdpMLineIndex, sdp);
                                peerConnections.get(data.getString("name")).addIceCandidate(ic);
                                break;
                            default:
                                Log.d(TAG, "Receiving " + "Unrecognized message");
                        }
                    } catch (JSONException e) {
                        return;
                    }

                }
            });
        }
    };

    public void initializeAddRecord(String connectionId) {
        InitializePeerConnectionFactory.create(this, connectionId);
    }

    public void initializeRecord(String connectionId) {
        if (connectionId.equals(username)) VideoTrackFromCameraAndShowIt.run(this);
        InitializePeerConnections.create(this, connectionId);

        if (connectionId.equals(username)) {
            startStreamingVideo();
            call(connectionId);
        }else{
            answer(connectionId);
        }
        /*new Timer().schedule(new TimerTask() {
            @Override
            public void run() {

            }
        }, 3000L);*/
    }

    private void startStreamingVideo() {
        MediaStream mediaStream = factories.get(username).createLocalMediaStream("ARDAMS");
        mediaStream.addTrack(videoTrackFromCamera);
        mediaStream.addTrack(localAudioTrack);
        peerConnections.get(username).addStream(mediaStream);
    }

    public void discount(String connectionId) {
        remove(connectionId);
        //Intent intent = new Intent(context, LoginActivity.class);
        //context.startActivity(intent);
    }


    public void call(String connectionId) {
        Log.d(TAG, "call: " + connectionId);

        MediaConstraints sdpMediaConstraints = new MediaConstraints();
        sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"));
        sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"));

        peerConnections.get(connectionId).createOffer(new SimpleSdpObserver() {
            @Override
            public void onCreateSuccess(SessionDescription sessionDescription) {
                Log.d(TAG, "onCreateSuccess: " + connectionId);
                peerConnections.get(connectionId).setLocalDescription(new SimpleSdpObserver(), sessionDescription);
                kurentoRoomAPI.sendReceiveVideoFrom(connectionId , sessionDescription.description);
            }
        }, sdpMediaConstraints);
    }

    public void answer(String connectionId) {
        Log.d(TAG, "answer: " + connectionId);

        MediaConstraints sdpMediaConstraints = new MediaConstraints();
        sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"));
        sdpMediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"));
        peerConnections.get(connectionId).createOffer(new SimpleSdpObserver() {
            @Override
            public void onCreateSuccess(SessionDescription sessionDescription) {
                Log.d(TAG, "onCreateSuccess createAnswer: " + connectionId);
                peerConnections.get(connectionId).setLocalDescription(new SimpleSdpObserver(), sessionDescription);
                kurentoRoomAPI.sendReceiveVideoFrom(connectionId , sessionDescription.description);
            }
        }, sdpMediaConstraints);
    }

    private RecordAdapter.RecordViewHolder.OnRecordItemBindEnd onRecordItemBindEnd = new RecordAdapter.RecordViewHolder.OnRecordItemBindEnd() {
        @Override
        public void OnRecordItemBindEnd(Record record) {
            initializeRecord(record.getConnId());
           /* if (useRecords.get(record.getConnId()) == null) {
                initializeRecord(record.getConnId());
                useRecords.put(record.getConnId(), true);
            }*/

        }
    };

    private RecordAdapter.RecordViewHolder.OnRecordItemClick onRecordItemClick = new RecordAdapter.RecordViewHolder.OnRecordItemClick() {
        @Override
        public void OnRecordClick(Record record) {

            Log.d(TAG, "OnRecordClick");
        }
    };


    public void remove(String connectionId) {
        VideoTrackFromCameraAndShowIt.stop();
        try {
            if (peerConnections.get(connectionId) != null) {
                peerConnections.get(connectionId).dispose(); // byH
            }
        }catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, e.toString());
        }

        try {
            if (audioSource != null) {
                audioSource.dispose();
                audioSource = null;
            }
        }catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, e.toString());
        }
        try {
            if(rootsEglBase.get(connectionId) != null){
                rootsEglBase.get(connectionId).release();
            }
        }catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, e.toString());
        }
        try {

            if(factories.get(connectionId) != null){
                factories.get(connectionId).dispose();
            }
            PeerConnectionFactory.stopInternalTracingCapture();
            PeerConnectionFactory.shutdownInternalTracer();

        }catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, e.toString());
        }

        try {
            recordAdapter.removeByName(connectionId);
            peerConnections.remove(connectionId);
            rootsEglBase.remove(connectionId);
            factories.remove(connectionId);
        }catch (Exception e) {
            e.printStackTrace();
        }




    }

}
