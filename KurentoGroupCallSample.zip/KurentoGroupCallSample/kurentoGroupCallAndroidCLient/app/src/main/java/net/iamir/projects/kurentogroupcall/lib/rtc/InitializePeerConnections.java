package net.iamir.projects.kurentogroupcall.lib.rtc;

import android.util.Log;
import android.widget.Toast;


import org.webrtc.AudioTrack;
import org.webrtc.DataChannel;
import org.webrtc.IceCandidate;
import org.webrtc.MediaStream;
import org.webrtc.PeerConnection;
import org.webrtc.RtpReceiver;
import org.webrtc.VideoTrack;

import java.util.ArrayList;

public class InitializePeerConnections {

    private static final String TAG = "iInitializePeerConnections";

    public Client parent;
    public String connectionId;

    public InitializePeerConnections(final Client client, String connectionId) {
        this.parent = client;
        this.connectionId = connectionId;
    }

    public static void create(final Client client,String connectionId) {
        InitializePeerConnections initializePeerConnections = new InitializePeerConnections(client, connectionId);
        client.peerConnections.put(connectionId, initializePeerConnections.createPeerConnection());
    }

    private PeerConnection createPeerConnection() {

        Log.d(TAG, "createPeerConnection: " + connectionId);

        // Add ICE Servers
        ArrayList<PeerConnection.IceServer> iceServers = new ArrayList<>();
        for(String i:parent.STUNList){
            PeerConnection.IceServer.Builder iceServerBuilder = PeerConnection.IceServer.builder(i);
            iceServerBuilder.setTlsCertPolicy(PeerConnection.TlsCertPolicy.TLS_CERT_POLICY_INSECURE_NO_CHECK); //this does the magic.
            PeerConnection.IceServer iceServer =  iceServerBuilder.createIceServer();
            iceServers.add(iceServer);
        }

        PeerConnection.RTCConfiguration rtcConfig = new PeerConnection.RTCConfiguration(iceServers);

        PeerConnection.Observer pcObserver = new PeerConnection.Observer() {
            @Override
            public void onSignalingChange(PeerConnection.SignalingState signalingState) {
              /*   * HAVE_LOCAL_OFFER
                 * HAVE_REMOTE_OFFER*/
                Log.d(TAG, "onSignalingChange -> " + connectionId + " : " + signalingState);
            }

            @Override
            public void onIceConnectionChange(PeerConnection.IceConnectionState iceConnectionState) {
                Log.d(TAG, "onIceConnectionChange -> " + connectionId + " : "  + iceConnectionState);
                ConnectionStatus(iceConnectionState.toString());
            }

            @Override
            public void onIceConnectionReceivingChange(boolean b) {
                Log.d(TAG, "onIceConnectionReceivingChange -> " + connectionId + " : " + b);
            }

            @Override
            public void onIceGatheringChange(PeerConnection.IceGatheringState iceGatheringState) {
                Log.d(TAG, "onIceGatheringChange -> " + connectionId + " : "  + iceGatheringState);
            }

            @Override
            public void onIceCandidate(IceCandidate iceCandidate) {
                Log.d(TAG, "onIceCandidate -> " + connectionId + " : " + iceCandidate);
                parent.kurentoRoomAPI.sendOnIceCandidate(connectionId, iceCandidate.sdp, Integer.toString(iceCandidate.sdpMLineIndex), iceCandidate.sdpMLineIndex);
            }

            @Override
            public void onIceCandidatesRemoved(IceCandidate[] iceCandidates) {
                Log.d(TAG, "onIceCandidatesRemoved -> "  + connectionId + " : " + iceCandidates);
            }

            @Override
            public void onAddStream(MediaStream mediaStream) {
                Log.d(TAG, "onAddStream -> "  + connectionId + " : " + mediaStream.videoTracks.size());
                VideoTrack remoteVideoTrack = mediaStream.videoTracks.get(0);
                AudioTrack remoteAudioTrack = mediaStream.audioTracks.get(0);
                remoteAudioTrack.setEnabled(true);
                remoteVideoTrack.setEnabled(true);
                remoteVideoTrack.addSink(parent.recordAdapter.findByName(connectionId).getVideView());
                //remoteVideoTrack.addSink(parent.binding.surfaceView2);
            }

            @Override
            public void onRemoveStream(MediaStream mediaStream) {
                Log.d(TAG, "onRemoveStream -> " + connectionId + " : " );
            }

            @Override
            public void onDataChannel(DataChannel dataChannel) {
                Log.d(TAG, "onDataChannel -> " + connectionId + " : " );
            }

            @Override
            public void onRenegotiationNeeded() {
                Log.d(TAG, "onRenegotiationNeeded -> " + connectionId + " : " );
            }

            @Override
            public void onAddTrack(RtpReceiver rtpReceiver, MediaStream[] mediaStreams) {

            }

            @Override
            public void onStandardizedIceConnectionChange(PeerConnection.IceConnectionState newState) {
                Log.d(TAG, "onStandardizedIceConnectionChange -> " + connectionId + " : " + newState.toString());

            }
        };

        PeerConnection peerConnection = parent.factories.get(connectionId).createPeerConnection(rtcConfig, pcObserver);

        return peerConnection;
    }

    public void ConnectionStatus(String s){
        parent.context.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    if(s.equals("CONNECTED")){
                        Toast.makeText(parent.context, "CONNECTED " + connectionId, Toast.LENGTH_SHORT).show();
                    }
                }catch (Exception e){
                    Log.e(TAG, "ConnectionStatus -> " + connectionId + " : " + e );
                }
            }
        });
    }
}