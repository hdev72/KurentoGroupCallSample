package net.iamir.projects.kurentogroupcall.lib.rtc;

import android.util.Log;


import org.webrtc.Camera1Enumerator;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraEnumerator;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.Logging;
import org.webrtc.MediaConstraints;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.SurfaceTextureHelper;
import org.webrtc.VideoCapturer;
import org.webrtc.VideoEncoderFactory;
import org.webrtc.VideoSource;

public class VideoTrackFromCameraAndShowIt {

    private static final String TAG = "iVideoTrackFromCameraAndShowIt";
    
    public Client parent;

    public VideoTrackFromCameraAndShowIt(final Client client) {
        parent = client;
    }

    public static Client run(final Client client) {
        VideoTrackFromCameraAndShowIt videoTrackFromCameraAndShowIt = new VideoTrackFromCameraAndShowIt(client);
        videoTrackFromCameraAndShowIt.createVideoTrackFromCameraAndShowIt();
        return client;
    }

    // how resolve A/libc: Fatal signal 11 (SIGSEGV), code 1, fault addr 0x59f97e16 in tid 28414 (CaptureThread)  ?
    // should dispose/null/close every thing like this method:
    /*private void closeInternal() {
        if (factory != null && peerConnectionParameters.aecDump) {
            factory.stopAecDump();
        }
        Log.d(TAG, "Closing peer connection.");
        statsTimer.cancel();
        if (dataChannel != null) {
            dataChannel.dispose();
            dataChannel = null;
        }
        if (peerConnection != null) {
            peerConnection.dispose();
            peerConnection = null;
        }
        Log.d(TAG, "Closing audio source.");
        if (audioSource != null) {
            audioSource.dispose();
            audioSource = null;
        }
        Log.d(TAG, "Stopping capture.");
        if (videoCapturer != null) {
            try {
                videoCapturer.stopCapture();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            videoCapturerStopped = true;
            videoCapturer.dispose();
            videoCapturer = null;
        }
        Log.d(TAG, "Closing video source.");
        if (videoSource != null) {
            videoSource.dispose();
            videoSource = null;
        }
        if (surfaceTextureHelper != null) {
            surfaceTextureHelper.dispose();
            surfaceTextureHelper = null;
        }
        localRender = null;
        remoteSinks = null;
        Log.d(TAG, "Closing peer connection factory.");
        if (factory != null) {
            factory.dispose();
            factory = null;
        }
        rootEglBase.release();
        Log.d(TAG, "Closing peer connection done.");
        events.onPeerConnectionClosed();
        PeerConnectionFactory.stopInternalTracingCapture();
        PeerConnectionFactory.shutdownInternalTracer();
    }
    //*/

    private static VideoCapturer videoCapturer;
    private static VideoSource videoSource;

    public static void stop(){

        if (videoCapturer != null) {
            try {
                videoCapturer.stopCapture();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            videoCapturer.dispose();
            videoCapturer = null;
        }
        Log.d(TAG, "Closing video source.");
        if (videoSource != null) {
            videoSource.dispose();
            videoSource = null;
        }
    }
    private void createVideoTrackFromCameraAndShowIt() {
        videoCapturer = createVideoCapturer();
        SurfaceTextureHelper surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThread", parent.rootsEglBase.get(parent.username).getEglBaseContext());
        videoSource = parent.factories.get(parent.username).createVideoSource(videoCapturer.isScreencast());
        videoCapturer.initialize(surfaceTextureHelper, parent.context, videoSource.getCapturerObserver());


        VideoEncoderFactory videoEncoderFactory =
                new DefaultVideoEncoderFactory(parent.rootsEglBase.get(parent.username).getEglBaseContext(), false, true);
        for (int i = 0; i < videoEncoderFactory.getSupportedCodecs().length; i++) {
            Log.d(TAG, "Supported codecs: " + videoEncoderFactory.getSupportedCodecs()[i].name);
        }

        parent.videoTrackFromCamera = parent.factories.get(parent.username).createVideoTrack("100", videoSource);

        //Create MediaConstraints - Will be useful for specifying video and audio constraints.
        parent.audioConstraints = new MediaConstraints();

        //create an AudioSource instance
        parent.audioSource = parent.factories.get(parent.username).createAudioSource(parent.audioConstraints);
        parent.localAudioTrack = parent.factories.get(parent.username).createAudioTrack("101", parent.audioSource);

        if (videoCapturer != null) {
            videoCapturer.startCapture(parent.VIDEO_RESOLUTION_WIDTH, parent.VIDEO_RESOLUTION_HEIGHT,parent. FPS);

        }

        // And finally, with our VideoRenderer ready, we
        // can add our renderer to the VideoTrack.
        parent.videoTrackFromCamera.setEnabled(true);

        parent.videoTrackFromCamera.addSink(parent.recordAdapter.findByName(parent.username).getVideView());
    }

    private boolean useCamera2() {
        return Camera2Enumerator.isSupported(parent.context);
    }

    private VideoCapturer createVideoCapturer() {
        VideoCapturer videoCapturer;
        Logging.d(TAG, "Creating capturer using camera1 API.");
        if (useCamera2()) {
            videoCapturer = createCameraCapturer(new Camera2Enumerator(parent.context));
        } else {
            videoCapturer = createCameraCapturer(new Camera1Enumerator(true));
        }
        return videoCapturer;
    }

    private VideoCapturer createCameraCapturer(CameraEnumerator enumerator) {
        final String[] deviceNames = enumerator.getDeviceNames();

        // First, try to find front facing camera
        Logging.d(TAG, "Looking for front facing cameras.");
        for (String deviceName : deviceNames) {
            if (enumerator.isFrontFacing(deviceName)) {
                Logging.d(TAG, "Creating front facing camera capturer.");
                VideoCapturer videoCapturer = enumerator.createCapturer(deviceName, null);

                if (videoCapturer != null) {
                    return videoCapturer;
                }
            }
        }

        // Front facing camera not found, try something else
        Logging.d(TAG, "Looking for other cameras.");
        for (String deviceName : deviceNames) {
            if (!enumerator.isFrontFacing(deviceName)) {
                Logging.d(TAG, "Creating other camera capturer.");
                VideoCapturer videoCapturer = enumerator.createCapturer(deviceName, null);

                if (videoCapturer != null) {
                    return videoCapturer;
                }
            }
        }
        return null;
    }

}
