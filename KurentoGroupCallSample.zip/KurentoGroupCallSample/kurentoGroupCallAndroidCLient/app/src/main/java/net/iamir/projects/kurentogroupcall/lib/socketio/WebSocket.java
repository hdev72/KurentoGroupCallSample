package net.iamir.projects.kurentogroupcall.lib.socketio;

import android.util.Log;

import org.json.JSONObject;

import java.net.URISyntaxException;

import io.socket.client.Ack;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class WebSocket {
    public Socket service;
    public String TAG = "SocketIO.WebSocket";

    public WebSocket(String uri) {

        Log.i(TAG, "connect: "+uri);
        IO.Options options = new IO.Options();
        options.transports = new String[]{"websocket"};
        options.reconnectionAttempts = 2;
        options.reconnectionDelay = 1000;
        options.timeout = 60000;
        options.rememberUpgrade = true;
        options.secure = true;

        SocketSSL.set(options);

        try {
            service = IO.socket(uri, options);
        } catch (URISyntaxException e) {
            Log.d(TAG, e.getMessage());
        }
        service.on(Socket.EVENT_CONNECT, onConnect);
        service.on(Socket.EVENT_DISCONNECT, onConnectError);
        service.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
        service.connect();
    }

    private Emitter.Listener onConnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG, "connected...");

        }
    };

    private Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG, "Error connecting...");
        }
    };

    public void send(String method,Object data) {
        try {
            service.emit(method, data);
        } catch (Exception e) {
            Log.i(TAG, "send: "+e.getMessage());
        }
    }

    public void sendMessage(JSONObject data) {
        try {
            service.send(data, new Ack() {
                @Override
                public void call(Object... args) {
                    Log.i(TAG, "sendMessage IOAcknowledge: "+ args.toString());
                }
            });
        } catch (Exception e) {
            Log.i(TAG, "sendMessage: "+e.getMessage());
        }
    }
}
