package net.iamir.projects.kurentogroupcall;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import net.iamir.projects.kurentogroupcall.databinding.ActivityGroupCallBinding;
import net.iamir.projects.kurentogroupcall.lib.EasyPermissions;
import net.iamir.projects.kurentogroupcall.lib.rtc.Client;

public class GroupCallActivity extends AppCompatActivity {

    public ActivityGroupCallBinding binding;
    public Client client;

    String TAG = "tagGroupCall";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityGroupCallBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);

        EasyPermissions.hasPermissions(this);
        client = new Client(this, binding);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_leave_room) {
            //client.kurentoRoomAPI.sendLeaveRoom();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        client.kurentoRoomAPI.sendLeaveRoom();
        client.discount(client.username);
        Log.e(TAG, "onDestroy");
        super.onDestroy();
    }


    @Override
    public void onBackPressed() {
        finish();
    }//*/
}