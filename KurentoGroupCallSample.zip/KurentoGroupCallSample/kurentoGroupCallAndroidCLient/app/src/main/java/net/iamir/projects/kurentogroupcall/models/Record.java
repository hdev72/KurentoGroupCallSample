package net.iamir.projects.kurentogroupcall.models;

import android.os.Parcel;
import android.os.Parcelable;


import org.webrtc.PeerConnection;
import org.webrtc.SurfaceViewRenderer;

public class Record implements Parcelable {

    private String type;
    private String connId;
    private String name;
    private String room;
    private SurfaceViewRenderer videView;
    public PeerConnection peerConnection;

    public String getType() {
        return type;
    }

    public String getConnId() {
        return connId;
    }

    public String getName() {
        return name;
    }

    public String getRoom() {
        return room;
    }

    public SurfaceViewRenderer getVideView() {
        return videView;
    }

    public PeerConnection getPeerConnection() {
        return peerConnection;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setConnId(String connId) {
        this.connId = connId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public void setVideView(SurfaceViewRenderer videView) {
        this.videView = videView;
    }

    public void setPeerConnection(PeerConnection peerConnection) {
        this.peerConnection = peerConnection;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.type);
        dest.writeString(this.connId);
        dest.writeString(this.name);
        dest.writeString(this.room);
        dest.writeParcelable((Parcelable) this.videView.getClass().getClassLoader(), flags);
        dest.writeParcelable((Parcelable) this.peerConnection.getClass().getClassLoader(), flags);
    }

    public Record() {

    }

    protected Record(Parcel in) {
        this.type = in.readString();
        this.connId = in.readString();
        this.name = in.readString();
        this.room = in.readString();
        this.videView = (SurfaceViewRenderer) in.readParcelable(this.videView.getClass().getClassLoader());
        this.peerConnection = (PeerConnection) in.readParcelable(this.peerConnection.getClass().getClassLoader());
    }

    public static final Creator<Record> CREATOR = new Creator<Record>() {
        @Override
        public Record createFromParcel(Parcel source) {
            return new Record(source);
        }

        @Override
        public Record[] newArray(int size) {
            return new Record[size];
        }
    };

}
