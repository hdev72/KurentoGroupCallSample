package net.iamir.projects.kurentogroupcall.lib.kurento;

import android.util.Log;

import net.iamir.projects.kurentogroupcall.lib.socketio.WebSocket;

import org.json.JSONObject;

import java.util.HashMap;



/**
 * Base class for API classes that handles web socket connections and Json-RPC requests and
 * responses.
 */
public abstract class KurentoAPI {
    private static final String LOG_TAG = "KurentoAPI";
    public WebSocket client = null;
    protected String wsUri = null;

    /**
     * Constructor that initializes required instances and parameters for the API calls.
     * WebSocket connections are not established in the constructor. User is responsible
     * for opening, closing and checking if the connection is open through the corresponding
     * API calls.
     *
     * @param uri is the web socket link to the room web services.
     */
    public KurentoAPI(String uri) {
        this.wsUri = uri;
    }

    /**
     * Opens a web socket connection to the predefined URI as provided in the constructor.
     * The method responds immediately, whether or not the connection is opened.
     * The method isWebSocketConnected() should be called to ensure that the connection is open.
     */
    public void connectWebSocket() {
        try {
            client = new WebSocket(wsUri);
            Log.e(LOG_TAG, "connecting socket.io");
        } catch (Exception exc){
            Log.e(LOG_TAG, "connect socket.io", exc);
        }
    }

    /**
     * Method to check if the web socket connection is connected.
     *
     * @return true if the connection state is connected, and false otherwise.
     */
    public boolean isWebSocketConnected(){
        return client != null;
    }

    /**
     * Attempts to close the web socket connection asynchronously.
     */
    public void disconnectWebSocket() {
        try {
            client.service.disconnect();
        } catch (Exception exc){
            Log.e(LOG_TAG, "disconnect socket.io", exc);
        }
    }

    /**
     *
     * @param method
     * @param namedParameters
     */
    protected void send(String method, HashMap<String, Object> namedParameters){

        try {
            namedParameters.put("id", method);
            Log.i(LOG_TAG, method);
            client.sendMessage(new JSONObject(namedParameters));
        } catch (Exception exc){
            Log.e(LOG_TAG, "send error: "+method, exc);
        }
    }
}
