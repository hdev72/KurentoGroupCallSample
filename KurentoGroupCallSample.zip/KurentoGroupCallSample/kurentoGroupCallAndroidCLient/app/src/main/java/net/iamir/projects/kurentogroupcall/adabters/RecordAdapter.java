package net.iamir.projects.kurentogroupcall.adabters;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import net.iamir.projects.kurentogroupcall.R;
import net.iamir.projects.kurentogroupcall.lib.rtc.Client;
import net.iamir.projects.kurentogroupcall.models.Record;

import org.json.JSONException;
import org.json.JSONObject;
import org.webrtc.EglBase;
import org.webrtc.SurfaceViewRenderer;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;


public class RecordAdapter extends RecyclerView.Adapter<RecordAdapter.RecordViewHolder> {

    private static final String TAG = "iRecordAdapter";

    public  List<Record> records = new ArrayList<>();

    public Client client;
    
    public RecordViewHolder.OnRecordItemClick onRecordItemClick;
    public RecordViewHolder.OnRecordItemBindEnd onRecordItemBindEnd;

    public RecordAdapter(Client client, RecordViewHolder.OnRecordItemClick onRecordItemClick, RecordViewHolder.OnRecordItemBindEnd onRecordItemBindEnd) {
        this.client = client;
        this.onRecordItemClick = onRecordItemClick;
        this.onRecordItemBindEnd = onRecordItemBindEnd;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void addRecords(List<Record> Records) {
        this.records.addAll(Records);
        notifyDataSetChanged();
    }
    
    @SuppressLint("NotifyDataSetChanged")
    public void addRecord(Record record) {
        this.records.add(record);
        notifyDataSetChanged();
    }



    @NonNull
    @Override
    public RecordViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View view = layoutInflater.inflate(R.layout.video, viewGroup, false);

        totalHeight = viewGroup.getMeasuredHeight();
        totalWidth = viewGroup.getMeasuredWidth();
        setWidthHeightOfItems(totalHeight, totalWidth);

        return new RecordViewHolder(view, onRecordItemClick, onRecordItemBindEnd);
    }


    int viewHeight ,viewWidth ;
    int totalHeight = 0, totalWidth = 0;
    int playersCount = 20;
    void setWidthHeightOfItems(int totalHeight, int totalWidth){
        int columnCount = 2;
        if(playersCount > 14){
            columnCount = 3;
        }
        int moreRow = 0;
        if(playersCount % columnCount != 0){
            moreRow++;
        }
        viewHeight = totalHeight / ((playersCount + moreRow) / columnCount);
        viewWidth = totalWidth / columnCount;
    }


    @Override
    public void onBindViewHolder(@NonNull RecordViewHolder holder, int position) {
        ViewGroup.LayoutParams fitParams =  holder.relativeItem.getLayoutParams();
        fitParams.height = viewHeight;
        fitParams.width = viewWidth;
        holder.relativeItem.setLayoutParams(fitParams);
        //holder.relativeItem.setMinimumWidth(viewWidth);
        //holder.relativeItem.setMinimumHeight(viewHeight);
        holder.bindRecord(this, records.get(position));
    }

    @Override
    public int getItemCount() {
        return records.size();
    }

    public static class RecordViewHolder extends RecyclerView.ViewHolder {
        private RelativeLayout relativeItem;
        private SurfaceViewRenderer RecordVideo;
        private TextView RecordName;

        private OnRecordItemClick onRecordItemClick;
        private OnRecordItemBindEnd onRecordItemBindEnd;
        

        public RecordViewHolder(View itemView, OnRecordItemClick onRecordItemClick, OnRecordItemBindEnd onRecordItemBindEnd) {
            super(itemView);
            this.onRecordItemClick = onRecordItemClick;
            this.onRecordItemBindEnd = onRecordItemBindEnd;
            relativeItem = (RelativeLayout) itemView.findViewById(R.id.relativeItem);
            RecordVideo = (SurfaceViewRenderer) itemView.findViewById(R.id.video_surface);
            RecordName = (TextView) itemView.findViewById(R.id.playerUsername);
        }

        public void bindRecord(RecordAdapter context, Record record) {
            if (record.getVideView() == null) {
                try {
                    RecordVideo.release();
                    RecordVideo.init(context.client.rootsEglBase.get(record.getConnId()).getEglBaseContext(), null);
                    //RecordVideo.init(context.client.rootEglBase.getEglBaseContext(), null);
                }catch (Exception e) {
                    Log.e(TAG,"bindRecord-> " + record.getName() + " : " + e.toString());
                }
                RecordVideo.setEnableHardwareScaler(true);
                RecordVideo.setMirror(true);
                record.setVideView(RecordVideo);
                RecordName.setText(record.getName());
                onRecordItemBindEnd.OnRecordItemBindEnd(record);
            }
        }

        public interface OnRecordItemClick {
            void OnRecordClick(Record record);
        }

        public interface OnRecordItemBindEnd {
            void OnRecordItemBindEnd(Record record);
        }
    }

    public void clear() {
        int size = records.size();
        records.clear();
        notifyItemRangeRemoved(0, size);
    }

    public Record findByName(String name) {
        for(Record record : records) {
            if (record.getName().equals(name)) {
                return record;
            }
        }
        return null;
    }

    public boolean removeByName(String name) {

        for (int i=0; i<records.size(); i++)
        {
            try{
                if (records.get(i).getName().equals(name)) {
                    records.remove(records.get(i));
                    notifyItemRangeRemoved(i, 1);
                    return true;
                }
            }catch (Exception e){
            }
        }
        return false;
    }

    public Record findById(String id) {
        for(Record record : records) {
            if (record.getConnId().equals(id)) {
                return record;
            }
        }
        return null;
    }

    public Record findLocal() {
        for(Record record : records) {
            if (record.getType().equals("local")) {
                return record;
            }
        }
        return null;
    }
}
