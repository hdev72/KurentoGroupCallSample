package net.iamir.projects.kurentogroupcall.lib.kurento;



import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.HashMap;



/**
 * Class that handles all Room API calls and passes asynchronous
 * responses and notifications to a RoomListener interface.
 */
public class KurentoRoomAPI extends KurentoAPI {

    public enum Method {JOIN_ROOM, PUBLISH_VIDEO, UNPUBLISH_VIDEO, RECEIVE_VIDEO, STOP_RECEIVE_VIDEO}

    private static final String LOG_TAG = "KurentoRoomAPI";
    private KeyStore keyStore;

    /**
     * Constructor that initializes required instances and parameters for the API calls.
     * WebSocket connections are not established in the constructor. User is responsible
     * for opening, closing and checking if the connection is open through the corresponding
     * API calls.
     *
     * @param uri is the web socket link to the room web services.
     */
    public KurentoRoomAPI(String uri){
        super(uri);

        // Create a KeyStore containing our trusted CAs
        try {
            keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
            keyStore.load(null, null);
        } catch (KeyStoreException | CertificateException | NoSuchAlgorithmException | IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method for the user to join the room. If the room does not exist previously,
     * it will be created.
     *
     * The response will contain the list of users and their streams in the room.
     *
     * @param userId is the username as it appears to all other users.
     * @param roomId is the name of the room to be joined.
     */
    @SuppressWarnings("unused")
    public void sendJoinRoom(String userId, String roomId){
        HashMap<String, Object> namedParameters = new HashMap<>();
        namedParameters.put("name", userId);
        namedParameters.put("roomName", roomId);
        send("joinRoom", namedParameters);
    }

    /**
     * Method will leave the current room.
     *
     */
    @SuppressWarnings("unused")
    public void sendLeaveRoom(){
        send("leaveRoom", new HashMap<String, Object>());
    }

    /**
     * Method to publish a video. The response will contain the sdpAnswer attribute.
     *
     * @param sdpOffer is a string sent by the client
     */
    @SuppressWarnings("unused")
    public void sendPublishVideo(String sender, String sdpOffer){
        HashMap<String, Object> namedParameters = new HashMap<>();
        namedParameters.put("sender", sender);
        namedParameters.put("sdpOffer", sdpOffer);
        send("receiveVideoFrom", namedParameters);
    }

    @SuppressWarnings("unused")
    public void sendReceiveVideoFrom(String sender, String sdpOffer){
        HashMap<String, Object> namedParameters = new HashMap<>();
        namedParameters.put("sender", sender);
        namedParameters.put("sdpOffer", sdpOffer);
        send("receiveVideoFrom", namedParameters);
    }

    /**
     * Method carries the information about the ICE candidate gathered on the client side.
     * This information is required to implement the trickle ICE mechanism.
     *
     * @param endpointName is the username of the peer whose ICE candidate was found
     * @param candidate contains the candidate attribute information
     * @param sdpMid is the media stream identification, "audio" or "video", for the m-line,
     *               this candidate is associated with.
     * @param sdpMLineIndex is the index (starting at 0) of the m-line in the SDP,
     *                      this candidate is associated with.
     */
    @SuppressWarnings("unused")
    public void sendOnIceCandidate(String endpointName, String candidate, String sdpMid, Integer sdpMLineIndex){
        HashMap<String, Object> namedParameters = new HashMap<>();
        namedParameters.put("sender", endpointName);
        JSONObject candidateObj = new JSONObject();
        try {
            candidateObj.put("candidate", candidate);
            candidateObj.put("sdpMid", sdpMid);
            candidateObj.put("sdpMLineIndex", sdpMLineIndex);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        namedParameters.put("candidate", candidateObj);
        send("onIceCandidate", namedParameters);
    }
}