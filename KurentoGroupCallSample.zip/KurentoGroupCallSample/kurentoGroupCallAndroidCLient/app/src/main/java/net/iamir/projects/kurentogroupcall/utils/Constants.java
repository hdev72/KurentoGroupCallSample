package net.iamir.projects.kurentogroupcall.utils;

public class Constants {
    public static final String USER_NAME = "net.iamir.projects.kurentogroupcall.userName";
    public static final String SERVER_NAME = "net.iamir.projects.kurentogroupcall.serverName";
    public static final String ROOM_NAME = "net.iamir.projects.kurentogroupcall.roomName";
    //public static final String DEFAULT_SERVER = "https://server103.iamir.net:8443";
    //public static String SERVER_ADDRESS_SET_BY_USER = "https://server103.iamir.net:8443";
    public static final String DEFAULT_SERVER = "https://192.168.1.2:8443";
    public static String SERVER_ADDRESS_SET_BY_USER = "https://192.168.1.2:8443";
    public static int id = 0;
}
