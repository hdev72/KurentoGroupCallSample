package net.iamir.projects.kurentogroupcall.lib.rtc;

import org.webrtc.DefaultVideoDecoderFactory;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.EglBase;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.VideoDecoderFactory;
import org.webrtc.VideoEncoderFactory;

public class InitializePeerConnectionFactory {

    public static void create(final Client client, String connectionId) {
        VideoEncoderFactory encoderFactory;
        VideoDecoderFactory decoderFactory;

        client.rootsEglBase.put(connectionId, EglBase.create());

        encoderFactory = new DefaultVideoEncoderFactory(client.rootsEglBase.get(connectionId).getEglBaseContext(), false /* enableIntelVp8Encoder */,true);
        decoderFactory = new DefaultVideoDecoderFactory(client.rootsEglBase.get(connectionId).getEglBaseContext());

        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(client.context).createInitializationOptions());
        client.factories.put(connectionId, PeerConnectionFactory.builder()
                .setVideoEncoderFactory(encoderFactory)
                .setVideoDecoderFactory(decoderFactory)
                .createPeerConnectionFactory());
    }

}
